<?php
class Crud extends CI_Controller {


	function __construct()
	{
		parent::__construct();
		$this->load->model('Mcrud');

	}

	public function index()
	{
		$this->load->view('form');
	}


	public function insert_data()
	{

				$this->Mcrud->model_function($_POST);
	}


	public function fetch_data()
	{
	$data=$this->Mcrud->model_select();

	$result=$data->result();
	print_r($result);


	}

	public function update()
	{
	$data=$this->Mcrud->model_update();
	echo "updated successfully";
	}


	public function delete()
	{
	$data=$this->Mcrud->model_delete();
	echo "deleted";
	}


}
?>


















>

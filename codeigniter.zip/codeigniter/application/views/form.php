<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body style="text-align:center">

    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <h2>USER DETAILS</h2>
    <form action="insert_data" method="post">
    Id:&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="id"><br><br>
    Name:&nbsp;&nbsp;<input type="text" name="name"><br><br>
    Mobile:&nbsp;&nbsp;<input type="text" name="mobile"><br><br>
    Email:&nbsp;&nbsp;<input type="text" name="email"><br><br>
    DOJ:&nbsp;&nbsp;<input type="date" name="doj"><br><br>
      <input type="submit" value="submit"><br><br>
    </form>
    </div>
    <div class="col-md-4"></div>
  </body>
</html>

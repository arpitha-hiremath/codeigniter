<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mcrud extends CI_Model {

  public function __construct(){
		parent::__construct();

	}

  function model_function($arrForm){
  $this->db->insert('trainers', $arrForm);
  echo "Inserted Successfully";

  }


  function model_select()
  {
    $sql = "select * from trainers";
    $query = $this->db->query($sql);
    return $query;

  }

  function  model_update()
  {

    $data = array(
        'name' => 'arpitha',
        'mobile'=>456677788,
        'doj' => '6-7-1999',
      );

    $this->db->where('id', 10);
    $this->db->update('trainers', $data);
  }

  function  modeldelete()
  {

    $data = array(
        'name' => 'arpitha',
        'mobile'=>456677788,
        'doj' => '6-7-1999',
      );

    $this->db->where('id', 10);
    $this->db->delete('trainers', $data);
  }
}
?>


?>
